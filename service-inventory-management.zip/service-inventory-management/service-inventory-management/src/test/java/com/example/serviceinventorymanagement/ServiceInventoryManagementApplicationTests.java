package com.example.serviceinventorymanagement;
import com.example.serviceinventorymanagement.controller.InventoryController;
import com.example.serviceinventorymanagement.exception.InventoryDoesNotExistException;
import com.example.serviceinventorymanagement.model.InventoryModel;
import com.example.serviceinventorymanagement.service.InventoryService;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.reactive.server.WebTestClient;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.util.UUID;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@WebFluxTest

class ServiceInventoryManagementApplicationTests {

    @Autowired
    private WebTestClient webTestClient;
    @MockBean
    private InventoryService inventoryService;

    @Test
    void showInventoryTest(){
        InventoryModel c=new InventoryModel(UUID.fromString("7a54c5c2-52ae-4018-83e4-6963a3416f23"),"237",30,4,5);
        Flux<InventoryModel> inventoryModelFlux=Flux.just(c);
        Mockito.when(inventoryService.showInventory()).thenReturn(inventoryModelFlux);
        Flux<InventoryModel> responseBody=webTestClient.get()
                .uri("/inventory/showinventory")
                .exchange()
                .expectStatus().isOk()
                .returnResult(InventoryModel.class)
                .getResponseBody();
        StepVerifier.create(responseBody)
                .expectSubscription()
                .expectNext(new InventoryModel(UUID.fromString("7a54c5c2-52ae-4018-83e4-6963a3416f23"),"237",30,4,5))
                .verifyComplete();


    }

    @Test
    void addInventoryTest(){
        InventoryModel c=new InventoryModel(UUID.fromString("ef8a9d0a-bb25-401b-9d53-3ec270d40623"),"425",18,1,5);
        Mono<InventoryModel> monoC=Mono.just(c);
        Mockito.when(inventoryService.addInventory(c)).thenReturn(monoC);

        webTestClient.post()
                .uri("/inventory/addinventory")
                .body(monoC, InventoryModel.class)
                .exchange()
                .expectStatus().isOk();

    }

    @Test
    public void updateInventoryTest(){
        InventoryModel c=new InventoryModel(UUID.fromString("ef8a9d0a-bb25-401b-9d53-3ec270d40623"),"425",23,6,2);
        Mono<InventoryModel> mono=Mono.just(c);
        Mockito.when(inventoryService.updateInventory(c,"425")).thenReturn(mono);
        webTestClient.put()
                .uri("/inventory/updateinventory/425")
                .body(mono, InventoryModel.class)
                .exchange()
                .expectStatus().isOk();
    }

    @Test
    public void findAnInventoryTest() throws InventoryDoesNotExistException {
        InventoryModel c=new InventoryModel(UUID.fromString("ef8a9d0a-bb25-401b-9d53-3ec270d40623"),"425",18,1,5);
        Mono<InventoryModel> monoC=Mono.just(c);
        Mockito.when(inventoryService.findInventoryById(any())).thenReturn(monoC);
        Flux<InventoryModel> responseBody=webTestClient.get()
                .uri("/inventory/findaninventory/425")
                .exchange()
                .expectStatus().isOk()
                .returnResult(InventoryModel.class)
                .getResponseBody();
        StepVerifier.create(responseBody)
                .expectSubscription()
                .expectNextMatches(p->p.getInStockQuantity().equals(18))
                .verifyComplete();

    }
    @Test
    public void reserveInventoryTest(){
        InventoryModel c=new InventoryModel(UUID.fromString("ef8a9d0a-bb25-401b-9d53-3ec270d40623"),"425",23,8,2);
        Mono<InventoryModel> mono=Mono.just(c);
        Mockito.when(inventoryService.updateInventory(c,"425")).thenReturn(mono);
        webTestClient.put()
                .uri("/inventory/reserveinventory/425")
                .body(mono, InventoryModel.class)
                .exchange()
                .expectStatus().isOk();
    }
    @Test
    public void createDemandTest(){
        InventoryModel c=new InventoryModel(UUID.fromString("ef8a9d0a-bb25-401b-9d53-3ec270d40623"),"425",21,6,4);
        Mono<InventoryModel> mono=Mono.just(c);
        Mockito.when(inventoryService.updateInventory(c,"425")).thenReturn(mono);
        webTestClient.put()
                .uri("/inventory/createdemand/425")
                .body(mono, InventoryModel.class)
                .exchange()
                .expectStatus().isOk();
    }

}
