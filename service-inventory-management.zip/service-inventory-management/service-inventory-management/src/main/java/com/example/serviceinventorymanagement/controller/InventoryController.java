package com.example.serviceinventorymanagement.controller;

import com.example.serviceinventorymanagement.exception.InventoryDoesNotExistException;
import com.example.serviceinventorymanagement.model.InventoryModel;
import com.example.serviceinventorymanagement.service.InventoryService;
import org.jetbrains.annotations.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;

@RestController
@RequestMapping("/inventory")
public class InventoryController {

    private final InventoryService inventoryService;

    @Autowired
    public InventoryController(InventoryService inventoryService) {
        this.inventoryService = inventoryService;
    }

    /*display an inventory by id*/
    @GetMapping(path = "findaninventory/{productsku}")
    public Mono<InventoryModel> findInventoryById(@PathVariable("productsku") String id) {
        return inventoryService.findInventoryById(id);
    }

    /*display all the inventory*/
    @GetMapping(path = "showinventory")
    public Flux<InventoryModel> showInventory() {
        return inventoryService.showInventory();
    }

    /*add inventory*/
    @PostMapping(path = "addinventory")
    public Mono<InventoryModel> addInventory(@Valid @RequestBody InventoryModel inventoryModel) {
        return inventoryService.addInventory(inventoryModel);
    }

    /*update inventory*/
    @PutMapping(path = "updateinventory/{productsku}")
    public Mono<InventoryModel> updateInventory(@RequestBody InventoryModel inventoryModel, @PathVariable("productsku") String id) {
        return inventoryService.updateInventory(inventoryModel, id);
    }

    /*reserve inventory*/
    @PutMapping(path = "reserveinventory/{productsku}")
    public Mono<InventoryModel> reserveInventory(@RequestBody InventoryModel inventoryModel, @PathVariable("productsku") String id) {
        return inventoryService.reserveInventory(inventoryModel, id);
    }

    /*create demand*/
    @PutMapping(path = "createdemand/{productsku}")
    public Mono<InventoryModel> createDemand( @RequestBody InventoryModel inventoryModel, @PathVariable("productsku") String id) {
        return inventoryService.createDemand(inventoryModel, id);
    }

    /* get available*/
    @GetMapping(path="getavailable/{productsku}")
    public Mono<InventoryModel> getAvailable(@PathVariable("productsku") String id)
    {
        return inventoryService.getAvailable(id);
    }


}
