package com.example.serviceinventorymanagement.model;
import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Transient;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import java.util.UUID;
@Table
@Data
public class InventoryModel {
    @Id
    private UUID id;
    @Column

    @NotBlank(message = "ProductSku should not be null")
    private String productSku;
    @NotNull(message = "In stock quantity should not be null")
    private Integer inStockQuantity;
    private Integer reserved;
    private Integer demand;

    @Transient
    private Integer available;

    public InventoryModel(UUID id,@NotBlank String productSku,@NotNull Integer inStockQuantity,Integer reserved, Integer demand){
        this.id=id;
        this.productSku=productSku;
        this.inStockQuantity=inStockQuantity;
        this.reserved=reserved;
        this.demand=demand;
    }


}
