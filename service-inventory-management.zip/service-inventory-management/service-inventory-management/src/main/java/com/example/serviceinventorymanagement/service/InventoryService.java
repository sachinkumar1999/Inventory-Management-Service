package com.example.serviceinventorymanagement.service;

import com.example.serviceinventorymanagement.exception.InventoryDoesNotExistException;
import com.example.serviceinventorymanagement.model.InventoryModel;
import com.example.serviceinventorymanagement.repo.InventoryRepository;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Service
public class InventoryService {
    private final InventoryRepository inventoryRepository;
    public InventoryService(InventoryRepository inventoryRepository){

        this.inventoryRepository=inventoryRepository;
    }

    /*find an inventory by id*/
    public Mono<InventoryModel> findInventoryById(String id)  {
        return inventoryRepository.findByProductSku(id)
                .switchIfEmpty(Mono.error(new InventoryDoesNotExistException("Inventory does not exist with id: "+id)));

    }

    /*show all the inventory*/
    public Flux<InventoryModel> showInventory(){

        return inventoryRepository.findAll();
    }

    /* Add an inventory*/
    public Mono<InventoryModel> addInventory(InventoryModel inventoryModel) {
        return inventoryRepository.save(inventoryModel);
    }

    /*update inventory*/
    public Mono<InventoryModel> updateInventory(InventoryModel inventoryModel,String id){
        return inventoryRepository.findByProductSku(id)
                .switchIfEmpty(Mono.error(new InventoryDoesNotExistException("Inventory does not exist with id: "+id)))
                .map((c)->{c.setInStockQuantity(inventoryModel.getInStockQuantity());
                    return c;})
                .flatMap(c->inventoryRepository.save(c));
    }

    /*reserve inventory*/
    public Mono<InventoryModel> reserveInventory(InventoryModel inventoryModel,String id){
        return inventoryRepository.findByProductSku(id)
                .switchIfEmpty(Mono.error(new InventoryDoesNotExistException("Inventory does not exist with id: "+id)))
                .flatMap(c->{
                    if(c.getReserved()==null)
                    {
                        c.setReserved(inventoryModel.getReserved());
                        return inventoryRepository.save(c);

                    }
                    else
                    {
                        c.setReserved(inventoryModel.getReserved()+c.getReserved());
                        return inventoryRepository.save(c);
                    }
                });
    }

    /*create demand*/
    public Mono<InventoryModel> createDemand(InventoryModel inventoryModel,String id){
        return inventoryRepository.findByProductSku(id)
                .switchIfEmpty(Mono.error(new InventoryDoesNotExistException("Inventory does not exist with id: "+id)))
                .flatMap(c->{
                    if(c.getDemand()==null)
                    {
                        c.setInStockQuantity(c.getInStockQuantity() - inventoryModel.getDemand());
                        c.setReserved(c.getReserved() - inventoryModel.getDemand());
                        c.setDemand(inventoryModel.getDemand());
                        return inventoryRepository.save(c);
                    }
                    else if(c.getReserved()>=inventoryModel.getDemand())
                    {
                        c.setInStockQuantity(c.getInStockQuantity() - inventoryModel.getDemand());
                        c.setReserved(c.getReserved() -inventoryModel.getDemand());
                        c.setDemand(inventoryModel.getDemand()+c.getDemand());
                        return inventoryRepository.save(c);
                    }
                    else
                    {
                        return inventoryRepository.findByProductSku(id);
                    }

                });

    }


    /*get available*/
    public Mono<InventoryModel> getAvailable(String id) {
        return inventoryRepository.findByProductSku(id)
                .switchIfEmpty(Mono.error(new InventoryDoesNotExistException("Inventory does not exist with id: "+id)))
                .flatMap(c->{
                    if(c.getReserved()==null)
                    {
                        c.setAvailable(c.getInStockQuantity());
                        return inventoryRepository.save(c);
                    } else if (c.getDemand()==null && (c.getInStockQuantity()-c.getReserved()>0)) {
                        c.setAvailable(c.getInStockQuantity()-c.getReserved());
                        return inventoryRepository.save(c);

                    }
                    else if(c.getInStockQuantity()-c.getReserved()-c.getDemand()>0) {
                        c.setAvailable(c.getInStockQuantity() - c.getReserved() - c.getDemand());
                        return inventoryRepository.save(c);
                    }
                    else{
                        c.setAvailable(0);
                        return inventoryRepository.save(c);

                    }
                });
    }
}
