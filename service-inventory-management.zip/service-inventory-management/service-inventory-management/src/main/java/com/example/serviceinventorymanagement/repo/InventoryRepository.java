package com.example.serviceinventorymanagement.repo;

import com.example.serviceinventorymanagement.model.InventoryModel;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.UUID;

public interface InventoryRepository extends ReactiveCrudRepository<InventoryModel, UUID> {

    public Mono<InventoryModel> findAllByProductSku(String id);
    public Mono<InventoryModel> findByProductSku(String id);


}
