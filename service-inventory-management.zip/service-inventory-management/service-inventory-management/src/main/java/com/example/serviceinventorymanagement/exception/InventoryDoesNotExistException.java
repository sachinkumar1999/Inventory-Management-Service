package com.example.serviceinventorymanagement.exception;

public class InventoryDoesNotExistException extends  Exception{
    public InventoryDoesNotExistException(String message)
    {
        super(message);
    }

}
